/opt/mssql/bin/sqlservr & /usr/data/import-data.sh & tail -f /dev/null
